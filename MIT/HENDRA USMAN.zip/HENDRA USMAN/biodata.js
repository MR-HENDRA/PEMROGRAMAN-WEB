alert("Welcome Mr. Hendra")

var nama = 'Hendra Usman';
var nim = 'D0221079';
var tempatLahir = 'Mamuju';
var tanggalLahir = 26;
var bulanLahir = 7;
var tahunLahir = 2003;
var alamat = 'Pullaewa Indah, Banggae Timur';
var hobi = 'Editing Video';
var sd = 'SD Inpres Sidomulyo';
var smp = 'SMP Negeri 1 Pangale';
var sma = 'SMA Negeri 1 Pangale';



console.log("BIODATA MAHASISWA");
console.log(" ");
console.log("Data Diri")
console.log("Nama Lengkap: " + nama);
console.log("NIM: " + nim);
console.log("Tempat, Tanggal Lahir: "+ tempatLahir + ", " + tanggalLahir + "-" + bulanLahir + "-" + tahunLahir);
console.log("Alamat: " + alamat);
console.log("Hobi: " + hobi);
console.log(" ");
console.log("Riwayat Pendidikan")
console.log("SD: " + sd);
console.log("SMP: " + smp);
console.log("SMA: " + sma);
